package pizzaProject;

public class Pizza {
	String name; // ���� �̸�
	int price;
	int totalOrder;

//	Materials materials;
//	int order; // �ֹ�

	Pizza(String name, int price) {
		this.name = name;
		this.price = price;
	
		this.totalOrder = 0;
//		this.materials = Materials.getInstance();
	}

	public void Order(int num) {
		System.out.println(this.name + " ���� �ֹ�: " + num);
		
		Materials materials = Materials.getInstance();

		if (this.name == "PizzaA") {
//			System.out.println("PizzaA: ");
			materials.doughA.Use(num);
			materials.cheeseA.Use(num);
			materials.topping1.Use(num);
			materials.topping2.Use(num);
			materials.topping3.Use(num);
			materials.topping4.Use(num);
			
		} else if (this.name == "PizzaB") {
//			System.out.println("PizzaB: ");
			materials.doughB.Use(num);
			materials.cheeseB.Use(num);
			materials.topping3.Use(num);
			materials.topping4.Use(num);
			materials.topping5.Use(num);
			materials.topping6.Use(num);
			
		} else {
			System.out.println("Unknown Pizza: ");
		}
		
		this.totalOrder += num; // �� order ����
		System.out.println("�� �ֹ� ����: " + this.totalOrder);
	}

	public String getName() {
		return this.name;
	}

	public int getPrice() {
		return this.price;
	}
	
	public int getTotalOrder() {
	    return this.totalOrder;
	}

	@Override
	public String toString() {
		return "Pizza [name=" + name + ", price=" + price + ", totalOrder=" + totalOrder + "]";
	}
	
}
