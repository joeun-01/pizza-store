package pizzaProject;

public class PizzaExample {
	public static void main(String[] args) {

//		PizzaExample pizzaExample = new PizzaExample();
		Materials materials = Materials.getInstance();
		
		Pizza pizzaA = new Pizza("PizzaA", 10000);
		Pizza pizzaB = new Pizza("PizzaB", 20000);
		  
		pizzaA.Order(1);
		pizzaB.Order(2);
		  
		System.out.println("pizzaA: " + pizzaA);
		System.out.println("pizzaB: " + pizzaB);
		System.out.println("materials: " + materials);

		pizzaA.Order(2);
		pizzaB.Order(3);
		  
		System.out.println("pizzaA: " + pizzaA);
		System.out.println("pizzaB: " + pizzaB);
		System.out.println("materials: " + materials);

	
		pizzaA.Order(3);
		pizzaB.Order(4);
		  
		System.out.println("pizzaA: " + pizzaA);
		System.out.println("pizzaB: " + pizzaB);
		System.out.println("materials: " + materials);

		pizzaA.Order(4);
		pizzaB.Order(5);
		  
		System.out.println("pizzaA: " + pizzaA);
		System.out.println("pizzaB: " + pizzaB);
		System.out.println("materials: " + materials);

		pizzaA.Order(5);
		pizzaB.Order(6);
		  
		System.out.println("pizzaA: " + pizzaA);
		System.out.println("pizzaB: " + pizzaB);
		System.out.println("materials: " + materials);
	}
}
