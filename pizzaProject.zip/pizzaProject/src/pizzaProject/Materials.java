package pizzaProject;

public class Materials {
    Material doughA;
    Material doughB;
    Material cheeseA;
    Material cheeseB;
    Material topping1;
    Material topping2;
    Material topping3;
    Material topping4;
    Material topping5;
    Material topping6;
	
	private Materials() {
	    this.doughA = new Material("����A", 1000, 10);
	    this.doughB = new Material("����B", 1000, 10);
	    this.cheeseA = new Material("ġ��A", 1000, 10);
	    this.cheeseB = new Material("ġ��B", 2000, 10);
	    this.topping1 = new Material("����1", 100, 10);
	    this.topping2 = new Material("����2", 200, 10);
	    this.topping3 = new Material("����3", 300, 10);
	    this.topping4 = new Material("����4", 400, 10);
	    this.topping5 = new Material("����5", 500, 10);
	    this.topping6 = new Material("����6", 600, 10);
	}
	private static Materials instance = new Materials();
	
	public static Materials getInstance() {
		if( instance == null) {
			instance = new Materials();
		}
		return instance;
	}

	@Override
	public String toString() {
		return "Materials Summary:" +
				"\n doughA=" + doughA + 
				"\n doughB=" + doughB + 
				"\n cheeseA=" + cheeseA + 
				"\n cheeseB=" + cheeseB	+ 
				"\n topping1=" + topping1 + 
				"\n topping2=" + topping2 + 
				"\n topping3=" + topping3 + 
				"\n topping4=" + topping4 + 
				"\n topping5=" + topping5 + 
				"\n topping6=" + topping6;
	}

}
